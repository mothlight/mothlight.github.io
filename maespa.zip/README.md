A soil-plant-atmosphere model based on MAESTRA and SPA
===================================================
  
Compiles with:
* Intel Visual Fortran Compiler (version >10). 
* gfortran

A Makefile is provided to compile Maes* on a Mac (thanks to Martin de Kauwe and Alejandro Morales).

[See this website for a full description of Maespa](http://maespa.github.io)